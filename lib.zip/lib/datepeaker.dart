import 'package:flutter/material.dart';

datepeaker() {
  return ListView(
    children: [
      TextFormField(
      ),
      TextFormField(
      ),
      TextFormField(
      ),
    ],
  );
}